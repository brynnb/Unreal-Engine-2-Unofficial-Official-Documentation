UnrealEngine 2.5 port of the SimpleSVehicleExamples
http://udn.epicgames.com/Two/SimpleSVehicleExamples

This is a rough port of the original example to version 3323. It's not great, but I'll try to improve it in the future.
To make the code work you will have to add the missing SVehicles to the system: SHover, SHelicopter and SHalfTrack. So for mod creators this might not be very usefull, just look at the runtime example and this code.


Some thanks go out to James Tan for exporting the Max modules so I could recreate the animation package.

-- Michiel Hendriks
