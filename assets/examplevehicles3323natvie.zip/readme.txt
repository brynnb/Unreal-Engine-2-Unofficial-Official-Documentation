UnrealEngine 2.5 port of the SimpleSVehicleExamples
http://udn.epicgames.com/Two/SimpleSVehicleExamples

These are the missing SVehicle classes in v3323. Note: these are not tested to work correctly.

-- Michiel Hendriks
