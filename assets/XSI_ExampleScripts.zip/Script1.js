CreatePrim("Sphere", "MeshSurface", null, null);
Create2DSkeleton(1.1037037037037, -3.23857386028092, 0, -1.62222222222222, -0.881899975682905, 0, 0, 0, 0, 4, null, null);
AppendBone("eff", 0.525925925925926, 0.704037795713244, 0, null);
AppendBone("eff", -0.229629629629629, 3.1941083152885, 0, null);
ApplyFlexEnv("sphere;bone,bone1,bone2,eff", false, 0);
ActorX();
ActorXSetValue("outputfolder", "c:\\temp");
ActorXSetValue("meshfilename", "mySphere");
ActorXSaveMesh();